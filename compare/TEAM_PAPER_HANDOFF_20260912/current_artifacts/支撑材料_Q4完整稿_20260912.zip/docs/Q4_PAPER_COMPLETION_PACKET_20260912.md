# Q4 论文补齐与证明状态包

更新时间：2026-09-12  
用途：作为继续撰写问题四、更新摘要与补齐当前论文缺口的唯一状态入口。

## 1. 当前决策

### Q2 末级平移量 `S10`

当前 `S10=775` 的性质仍是：在已证明前缀

\[
(R,R_A,R_B,M,M_A,M_B)=(6,0,4,126,16,34)
\]

下得到的可行上界，尚未证明为最小值。本轮对直接阈值
`S10≤774` 的 CP-SAT 检查使用相同的 4,582 个候选动作和相同前缀，运行 600 秒后返回
`UNKNOWN/NOT_PROVED`，见 `tmp/q2_shift_le_774_20260912.json`。

本阶段不再继续投入该层证明，理由是：

1. `S10` 不改变 Q2 的主目标 `R=6` 和已经闭合的前五个次级层；
2. Q3 使用的是已经批准的具体 `result2.xlsx`，不依赖 `S10` 是否达到最小；
3. 当前论文可以明确把 `S10=775` 写成“已闭合前缀下的可行并列方案上界”；
4. 若将来要声称 Q2 七层字典序完全最优，才需要继续做 `S10≤774` 的不可行证明或等价的形式化证书。

因此，Q2 的论文主线可以继续，不应把 `775` 改写成完整字典序最优值。

### Q4 次级目标

Q4 最重要的主结论已经闭合：

\[
R\le3\text{ 可行},\qquad R\le2\text{ 不可行}
\quad\Longrightarrow\quad R_{Q4}^{\ast}=3.
\]

`R=3` 内的 `R_A、R_B、M、M_A、M_B、S_{10}^{(4)}` 不必在补齐论文前全部证明。当前应采用“最小撤销层已证明 + 同一最小层下给出一个可复核的优先级候选”的写法，而不是停留在 Q4 未写入论文的状态。

若以后要声称 `result4.xlsx` 是完整次级字典序全局最优，则仍需依次证明：

\[
R_B=1,\quad M=142,\quad M_A,\quad M_B,\quad S_{10}^{(4)}=943.
\]

目前这些层不应写成已证明最优。

## 2. Q4 当前证据矩阵

| 层级 | 当前数值 | 证据 | 状态 | 论文允许的说法 |
|---|---:|---|---|---|
| 最小撤销数 `R` | 3 | `proof_R_le_3.json` + 独立验证；六个 `R=2` 类别分支 `UNSAT` | 已证明 | 在当前有限模型和 `H=643` 下，最少撤销 3 台 |
| A 类撤销 `R_A` | 0 | `conditional_R3_chain.json` 的第一阶段为 `OPTIMAL`；0 为自然下界 | 条件最优 | 固定 `R=3` 后，A 类撤销数可达到其理论下界 0 |
| B 类撤销 `R_B` | 1 | `conditional_R3_RB1_chain.json` | 可行候选 | 当前候选使用 1 台 B 类撤销，尚未证明不能为 0 |
| 调整计划数 `M` | 142 | `conditional_R3_RB1_chain.json` | 可行候选 | 在上述候选前缀下得到 142 个调整计划，尚未证明最少 |
| A/B 类调整数 | 20 / 39 | 同上 | 可行候选 | 作为当前候选的类别统计，不写成条件最优 |
| Q4 末级 `S_{10}^{(4)}` | 943 | 同上 | 可行候选 | 作为当前候选的平移/间隔变化总量，不写成最优 |

当前 `result4.xlsx` 的三类统计为：

| 类别 | 保留 | 调整 | 撤销 |
|---|---:|---:|---:|
| A | 0 | 20 | 0 |
| B | 0 | 39 | 1 |
| C | 5 | 83 | 2 |
| 合计 | 5 | 142 | 3 |

注意：`proof_R_le_3.json` 是独立的三撤销可行见证，其撤销编号为 `A012、B018、B033`；用于最终填写模板的 `result4.xlsx` 来自另一组条件候选，其撤销编号为 `B029、C035、C075`。二者都可证明 `R≤3` 可行，但论文中的工作簿、类别统计和动作清单必须来自同一个文件，不能交叉拼接。

## 3. Q4 模型与证明链

### 3.1 有限动作集合

对每个计划只允许选择一个动作：

\[
\mathcal A_i=\{\text{keep},\text{freq}(\delta f),\text{time}(\delta t),\text{revoke}\},
\]

其中

\[
\delta f\in\{-10,\ldots,-1,1,\ldots,10\},\qquad
\delta t\in\{-5,\ldots,-1,1,\ldots,5\}.
\]

C 类额外允许

\[
\delta g\in\{-8,\ldots,-1,1,\ldots,10\},
\qquad g'=8+\delta g\in\{0,1,\ldots,18\}.
\]

选择间隔调整时，频段和首次时间保持原值；使用次数和单次占用时长保持不变。所有候选动作先展开完整重复事件，再检查时间域 `[0,643)` 和频率域 `[0,100)`。

### 3.2 重复事件递推

若首次事件为 `[s_i,e_i)`，单次时长为 `d_i=e_i-s_i`，调整后空闲间隔为 `g'_i`，则第 `k` 次事件为

\[
T_{i,k}=[s_i+k(d_i+g'_i),\ e_i+k(d_i+g'_i)),
\qquad k=0,\ldots,n_i-1.
\]

间隔变化会联动第二次及以后的所有事件，不能只移动某一个时间段。

### 3.3 `R≤2` 全局不可行证明

证明链应按以下顺序写：

1. 若存在少于 2 台撤销的可行方案，可以再任意撤销计划补足到恰好 2 台；撤销不会产生新的资源冲突。因此只需检验恰好 2 台撤销。
2. 恰好 2 台撤销在 A、B、C 三类间只有六种分拆：

   `(0,0,2)、(0,1,1)、(0,2,0)、(1,0,1)、(1,1,0)、(2,0,0)`。

3. Q4 共生成 6,103 个合法候选动作，其中 5,953 个为活动动作。对同一计划内的活动动作，若 `N(b)⊆N(a)`，则动作 `a` 可以被动作 `b` 替换而不引入新的外部冲突。该支配消元将活动动作从 5,953 个缩减为 5,533 个。
4. 新增的 `proof_R_le_2_dominance_validation.json` 逐动作核验了 420 个被消去动作均有同计划、已保留的支配动作；150 个计划均至少保留一个活动动作，故不改变类别撤销分支。
5. 对六种类别分拆分别保留全部计划身份和合法活动动作，建立 `target_active=148` 的 SAT 判定模型。六个分支均返回 `UNSAT/PROVED_INFEASIBLE`。
6. 因此 `R≤2` 不可行；结合独立验证通过的三撤销可行方案，得到 `R_{Q4}^*=3`。

六个分支只证明当前有限整数模型下的阈值不可行，不等同于连续参数或任意未列入动作集合的模型下的数学结论。

## 4. 可直接放入论文的问题四正文

### 4.1 模型建立

问题四在问题二动作框架的基础上，仅对 C 类计划增加空闲间隔调整。令 `x_{i,a}` 表示计划 `i` 是否选择动作 `a`，每个计划满足

\[
\sum_{a\in\mathcal A_i}x_{i,a}=1.
\]

对每个候选动作预先展开其全部重复事件，并记其占用的离散时频资源格集合为 `C_{i,a}`。对任意资源格 `c`，加入

\[
\sum_{(i,a):,c\in C_{i,a}}x_{i,a}\le1,
\]

即可保证所有活动计划在时间和频率两个维度均无冲突。目标按撤销数、A 类撤销数、B 类撤销数、调整计划数、A/B 类调整数和末级变化量进行字典序比较；本文首先闭合决定方案规模的最小撤销层。

### 4.2 最小撤销数证明

在 `H=643`、频率域 `[0,100)`、整数时频资源格和上述有限动作集合下，首先构造一组 3 台撤销的无冲突可行方案，并通过连续区间重建、离散资源格检查和工作簿回读确认其合法性。为证明 2 台及以下撤销不可行，若某方案撤销数小于 2，可继续撤销计划补足到 2 台而不破坏无冲突性，故只需考察恰好 2 台撤销。两台撤销在 A、B、C 三类之间有六种类别分拆。对六种分支分别保留全部计划身份和全部合法活动动作，建立 SAT 判定模型，六个分支均返回不可满足。候选动作的支配消元已逐动作复核为等价替换，不改变分支可行性。因此，2 台及以下撤销均不可行，结合 3 台可行见证，得到问题四在本文有限模型下的最小撤销数为 3 台。

### 4.3 结果与边界

最终工作簿 `result4.xlsx` 给出一组 3 台撤销的可行方案：A 类为 `0/20/0`，B 类为 `0/39/1`，C 类为 `5/83/2`（保留/调整/撤销），总调整计划数为 142。独立回读确认 147 个计划处于活动状态，连续区间冲突数和离散资源格冲突数均为 0，越界数为 0，最大资源格占用数为 1。需要强调的是，`R=3` 已证明为最小撤销层，但当前 `R_B=1、M=142` 和 `S_{10}^{(4)}=943` 仍是该最小层下的可行候选，而非已经闭合的次级全局最优值。

在 `H=638,643,648` 三个时间边界下均找到通过验证的 3 台撤销候选；目前边界分析支持的是“3 台撤销可行上界对边界扰动稳定”，不把 `H=638` 和 `H=648` 下的最小撤销数也写成已证明为 3。

## 5. 当前论文需要同步修改的地方

1. 摘要增加问题四：说明 C 类间隔可调、`R_{Q4}^*=3`，并注明这是当前有限动作集合和 `H=643` 下的结果。
2. 删除或替换论文中“问题四尚未运行”“问题四结果尚未生成”等旧表述。
3. 新增问题四章节，至少包含：动作集合、间隔递推、资源格约束、六分支 `UNSAT` 证明、结果统计、工作簿校验和边界说明。
4. 结论中把 Q2 的 `S10=775`、Q4 的 `R_B=1/M=142/S_{10}^{(4)}=943` 标记为可行上界或条件候选，不称为完整字典序最优。
5. 将 Q4 的“最小撤销层证明”和“当前候选方案”分成两个表格，避免读者误以为整个 `result4.xlsx` 已被完整优化证明。
6. Q4 的正式结果若插图或制表，数字必须从 `conditional_R3_RB1_chain.json` 与对应验证文件同源读取；不能把 `proof_R_le_3.json` 的另一组动作清单混入。

## 6. 证据入口与复核命令

主要证据：

- Q4 总结：[outputs/q4/summary.md](../outputs/q4/summary.md)
- Q4 `R≤2` 证明说明：[outputs/q4/r2_global_proof_status.md](../outputs/q4/r2_global_proof_status.md)
- 六分支覆盖：[outputs/q4/proof_R_le_2_global_coverage_validation.json](../outputs/q4/proof_R_le_2_global_coverage_validation.json)
- 支配替换证书：[outputs/q4/proof_R_le_2_dominance_validation.json](../outputs/q4/proof_R_le_2_dominance_validation.json)
- 三撤销独立验证：[outputs/q4/proof_R_le_3_validation.json](../outputs/q4/proof_R_le_3_validation.json)
- 当前工作簿独立回读：[outputs/q4/result4_workbook_validation_independent.json](../outputs/q4/result4_workbook_validation_independent.json)
- Q4 候选链：[outputs/q4/conditional_R3_RB1_chain.json](../outputs/q4/conditional_R3_RB1_chain.json)
- Q2 前缀证明矩阵：[outputs/q2/q2_proof_matrix.csv](../outputs/q2/q2_proof_matrix.csv)
- Q2 末级阈值探索：[tmp/q2_shift_le_774_20260912.json](../tmp/q2_shift_le_774_20260912.json)

推荐复核入口：

```text
python -m scripts.validate_q2 --result outputs/q2/results.json --output tmp/audit_q2_validation_20260912.json --horizon 643
python -m scripts.verify_q3_optimality --input data/raw/D题/附件/附件1.xlsx --q2-result outputs/q2/results.json --q3-result outputs/q3/results.json --output tmp/audit_q3_optimality_20260912.json
python -m scripts.validate_q4 --result outputs/q4/conditional_R3_RB1_chain.json --output tmp/audit_q4_validation_20260912.json --horizon 643
python -m scripts.verify_q4_dominance_certificate --horizon 643 --output tmp/audit_q4_dominance_validation_20260912.json
python -m scripts.verify_q4_r2_global_proof --horizon 643 --proof outputs/q4/proof_R_le_2_active_sat_r2_A0B0C2_pruned120.json --proof outputs/q4/proof_R_le_2_active_sat_r2_A0B1C1_compact600.json --proof outputs/q4/proof_R_le_2_active_sat_r2_A0B2C0_pruned300.json --proof outputs/q4/proof_R_le_2_active_sat_r2_A1B0C1_pruned300.json --proof outputs/q4/proof_R_le_2_active_sat_r2_A1B1C0_pruned300.json --proof outputs/q4/proof_R_le_2_active_sat_r2_A2B0C0_pruned300.json --output tmp/audit_q4_r2_coverage_20260912.json
```

最终原则：`UNKNOWN`、超时、历史旧方案和未闭合的末级指标都只能作为审计记录，不能升级为最优性证明。
