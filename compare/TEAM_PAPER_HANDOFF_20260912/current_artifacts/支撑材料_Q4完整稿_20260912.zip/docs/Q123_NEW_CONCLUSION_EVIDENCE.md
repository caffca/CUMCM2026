# 问题 1—3 新结论—证据—正文位置—图表需求清单

## 0. 台账范围

- **时间截点**：2026-09-11。
- **纳入范围**：当前工作区重新求解、独立验证和结果整理得到的问题 1—3。
- **排除范围**：`paper/` 下旧稿文字、旧稿公式、旧稿图表、旧稿 PDF 和旧稿排版；它们不作为证据来源。
- **问题四**：暂不纳入本台账。
- **旧结果**：问题二旧的 19 次撤销方案、问题三旧的 203 台新增方案已 supersede，不进入主结论；如需讨论，只能作为历史诊断并明确标注。
- **图表风格**：证据优先的冷静科研风；类别变量采用低饱和蓝—橙或蓝—青，连续变量采用感知均匀色图；图表按“图表类别”分工，不按软件名称分工。

## 1. 状态标记

- `A—正文候选`：有直接结果文件和独立验证，可进入正文，但仍需随新解题方案复核。
- `B—条件性正文候选`：结论成立，但依赖固定资源域、固定 Q2 接口或已声明的模型前缀。
- `C—验证/敏感性`：用于模型检验、边界或稳健性说明，不宜作为主结论。
- `D—保留限制`：必须在正文中如实说明的未闭合项或结论边界。
- `E—暂不使用`：已有文件，但不满足当前证据要求或属于旧方案。

## 2. 共同数据处理结论

| ID | 状态 | 新结论 | 主要证据 | 验证与边界 | 正文位置 | 图表需求 |
|---|---|---|---|---|---|---|
| DP-1 | A—正文候选 | 原始附件包含 150 条唯一用频计划，字段完整，无缺失、重复行和错误单元格；A/B/C 类分别为 20/40/90 条。频段和时间区间均为合法半开整数区间。 | `work/intake/DATA_AUDIT.md`；`work/intake/FILE_MANIFEST.json`；`data/raw/D题/附件/附件1.xlsx` | 原始数据只读；不把类别统计直接当作新增 C 类定义。 | 一级标题“数据预处理—数据来源与质量审计” | 可用一张简洁的数据结构表；不需要装饰性图。
| DP-2 | A—正文候选 | 将每条计划按“单次时长 + 空闲间隔”展开，采用半开区间；第 (k) 次事件为 ([s+k(l+g),e+k(l+g)))。由数据展开得到统一时间域 ([0,643)\times[0,100))。 | `work/intake/DATA_AUDIT.md`；`outputs/q1/summary.md`；`outputs/q1/validation.json` | A001 示例、C083 末次事件和独立离散单元检查均通过；643 是数据驱动边界，不是题面直接给定常量。 | “数据预处理—重复事件展开与时频离散化” | 一张窄版流程图：原始计划 → 重复事件 → 半开时频单元 → 冲突/优化输入；Mermaid 源文件后续转 SVG。
| DP-3 | B—条件性正文候选 | Q1—Q3 共用同一套半开区间、整数时频单元和边界口径；Q2、Q3 的资源域固定为 ([0,643)\times[0,100))。 | `work/intake/PROBLEM_MAP.md`；`outputs/q2/summary.md`；`outputs/q3/q3_optimization_audit.md` | 若改变全局时间域或端点语义，Q2、Q3 必须重算。 | “数据预处理—跨问题接口与边界” | 用文字和小表说明，不另做复杂图。

## 3. 问题一：冲突检测

| ID | 状态 | 新结论 | 主要证据 | 验证与边界 | 正文位置 | 图表需求 |
|---|---|---|---|---|---|---|
| Q1-1 | A—正文候选 | 150 条计划展开为 1,300 个重复事件，检查 (\binom{150}{2}=11,175) 个候选装备对。 | `outputs/q1/summary.md`；`outputs/q1/results.json`；`outputs/q1/validation.json` | 独立事件重数复核和输入边界检查通过。 | “问题一—模型建立与求解—事件展开与冲突判定” | 可放在正文中的结果概览表；不需要单独柱状图。
| Q1-2 | A—正文候选 | 检出 297 对冲突装备，占全部候选装备对的 2.66%；对应 431 次事件级重叠。297 是装备对指标，431 是事件重叠指标，二者不能混用。 | `outputs/q1/results.json`；`outputs/q1/conflict_pairs.csv`；`outputs/q1/validation.json`；`outputs/q1/result1.xlsx` | 连续半开区间算法与独立离散时频单元算法完全一致；结果表 297 行、序号连续且唯一。 | “问题一—结果与检验” | 结果表承担精确清单；图只展示结构，不重复列出 297 行。
| Q1-3 | A—正文候选 | 148 个装备参与至少一次冲突，C007、C060 为孤立装备；冲突图有 3 个连通分量，最大分量含 148 个装备，平均冲突度 3.96，最大冲突度 8。 | `outputs/q1/results.json`；`outputs/q1/plot_data/degree_by_plan.csv`；`outputs/q1/plot_data/component_sizes.csv` | 仅用于描述原始冲突结构，不据此直接决定 Q2 的平移对象。 | “问题一—冲突网络结构” | 图表类别：网络/邻接结构 + 度分布；必要时保留为一张双面板图。
| Q1-4 | A—正文候选 | B—C 类共 181 对冲突，占全部冲突对的 60.94%；按 3,600 个可能 B—C 配对归一化后冲突率为 5.03%，六类组合中最高。 | `outputs/q1/results.json`；`outputs/q1/plot_data/conflict_counts_by_category.csv`；`outputs/q1/figure_briefs.md` | 这是冲突结构定位证据，不等于 Q2 的动作选择规则。 | “问题一—类别结构分析”；“问题二—模型动机” | 图表类别：类别组合比较；低饱和蓝—橙/蓝—青，标注“冲突数/可配对数”。
| Q1-5 | A—正文候选 | Q1 的冲突清单可作为 Q2 的硬约束输入；原始数据、结果 JSON、CSV 和模板工作簿逐项一致。 | `outputs/q1/summary.md`；`outputs/q1/validation.json`；`scripts/solve_q1.py`；`scripts/validate_q1.py` | Q2 必须重新展开调整后的全部重复事件，不能只使用 Q1 的首次事件。 | “问题一小结”与“问题二—输入接口” | 不单独制图；在流程图中作为接口节点表示。

## 4. 问题二：冲突消解

| ID | 状态 | 新结论 | 主要证据 | 验证与边界 | 正文位置 | 图表需求 |
|---|---|---|---|---|---|---|
| Q2-1 | A—正文候选 | 对每个原计划枚举保留、频移、时移和撤销动作；频移满足 \\(|\\Delta f|\\le10\\)，时移满足 \\(|\\Delta t|\\le5\\)，一次至多调整一个参数，完整重复事件必须落在统一资源域内。共形成 4,582 个候选动作，并用 52,939 条资源格团约束实现全局冲突消解。 | `outputs/q2/summary.md`；`outputs/q2/q2_optimization_audit.md`；`outputs/q2/results.json`；`work/q2/MODEL_CARD.md` | 270,626 条候选成对冲突边被压缩为资源格约束；调整后时长、间隔和使用次数保持不变。 | “问题二—数据接口与候选动作”“问题二—模型建立” | 图表类别：模型结构/约束压缩示意；可用一张简化的候选动作 → 资源格约束流程图。
| Q2-2 | A—正文候选 | 总撤销数的最优值为 (R^*=6)，CP-SAT 给出 LB=UB=6。 | `outputs/q2/revocation_bound.json`；`outputs/q2/validation.json`；`outputs/q2/q2_proof_matrix.csv` | 主目标已证明；不可将旧 19 次撤销结果写入正文。 | “问题二—主目标求解与最优性证明” | 图表类别：上下界/证明状态；用点线或短表表示 LB=UB，不使用夸大的“最优”装饰图。
| Q2-3 | A—正文候选 | 在条件字典序 (R\rightarrow R_A\rightarrow R_B\rightarrow M\rightarrow M_A\rightarrow M_B) 下，已闭合前缀为 ( (6,0,4,126,16,34) )：总撤销、A 类撤销、B 类撤销、总调整、A 类调整、B 类调整均有对应上下界或阈值不可行证据。 | `outputs/q2/q2_proof_matrix.csv`；`outputs/q2/proof/sat_b_le_3.json`；`outputs/q2/proof/sat_adjust_le_125.json`；`outputs/q2/proof/sat_adjust_a_le_15.json`；`outputs/q2/proof/sat_adjust_b_le_33.json`；`outputs/q2/priority_prefix_run.json` | 这是“已证明字典序前缀”，不是整条包含末级平移量的完整字典序最优。 | “问题二—字典序目标与阈值证明” | 图表类别：证明链/目标层级状态；建议重绘为“层级—LB—UB—状态”窄表或水平阶梯图。
| Q2-4 | A—正文候选 | 当前正式六撤销方案为 A 类 4/16/0、B 类 2/34/4、C 类 12/76/2（保留/调整/撤销）；共 144 个活动计划，占用 15,816 个不同资源格，无连续冲突、无离散冲突、无越界和重复占用。 | `outputs/q2/six_revocation_candidate.json`；`outputs/q2/six_revocation_validation.json`；`outputs/q2/validation.json`；`outputs/q2/result2.xlsx`；`outputs/q2/workbook_validation.json` | 工作簿验证 132 条动作行通过；方案是 Q3 的唯一冻结接口。 | “问题二—结果与独立验证”；“问题三—固定输入” | 图表类别：类别构成比较；建议堆叠条或分组条，精确动作清单放附录/支撑文件。
| Q2-5 | C—验证/敏感性 | 在 (H\in\{638,643,648\}) 三个时间域情景中，最小撤销数均为 6；H=638、648 的方案需要各自边界合法性见证。 | `outputs/q2/boundary_sensitivity.json`；`outputs/q2/proof/cp_sat_H638_Rle5.json`；`outputs/q2/proof/cp_sat_H648_Rle5.json`；`tmp/q2_cp_sat_feas6_H638_repair_hint_validation.json`；`tmp/q2_review_formal_H648_validation.json` | 适合放在模型检验/边界敏感性，不应替代 H=643 基准方案；其余字典序层未在三个情景中全部闭合。 | “模型检验—时间域敏感性” | 图表类别：情景比较；用低饱和蓝—青表示 H，橙色仅标出撤销数，不画连续热力图。
| Q2-6 | D—保留限制 | 归一化平移量 (S_{10}=775) 只是当前六撤销方案的可行上界，末级 (S_{10}\le774) 未完成全局不可行证明；不能写成完整字典序最优。 | `outputs/q2/q2_optimization_audit.md`；`outputs/q2/q2_proof_matrix.csv`；`outputs/q2/six_revocation_candidate.json`；`outputs/q2/figure_briefs.md` | 这是论文必须保留的诚实边界；现有 Q2 图表标记为 `STALE_PENDING_FINAL_REDRAW`，不直接作为最终图。 | “问题二—最优性边界”；“模型优缺点评价” | 图表类别：证明状态/边界说明；重绘时明确区分“已证明”和“可行上界”。

## 5. 问题三：新增 C 类装备

| ID | 状态 | 新结论 | 主要证据 | 验证与边界 | 正文位置 | 图表需求 |
|---|---|---|---|---|---|---|
| Q3-1 | B—条件性正文候选 | Q3 固定经批准的 Q2 工作簿，Q2 有 144 个活动计划，占用 15,816 个资源格；Q3 不反向修改 Q2。 | `outputs/q3/q2_input_from_result2.json`；`outputs/q3/results.json`；`outputs/q3/validation.json`；`outputs/q2/result2.xlsx` | 结论依赖当前具体 Q2 方案和用户批准的接口。 | “问题三—固定背景与候选生成” | 图表类别：问题间接口流程；可并入总流程图，不重复画 Q2 方案。
| Q3-2 | A—正文候选 | 按附件 C 类共同结构生成完整候选：频段宽 3、单次时长 2、间隔 8、使用 12 次、相邻起点步长 10；在 (f_0=0,ldots,97)、(t_0=0,ldots,531) 上共枚举 52,136 个起点，筛得 2,334 个与固定 Q2 不冲突的候选。 | `outputs/q3/results.json`；`outputs/q3/q3_optimality_audit.json`；`outputs/q3/plot_data/feasible_candidate_starts.csv`；`work/q3/MODEL_CARD.md` | 不用“剩余面积/72”代替完整模板可行性；候选没有抽样。 | “问题三—数据预处理与候选集合” | 图表类别：二维候选空间/可行域；蓝色表示可行候选，橙色表示最终选中候选。
| Q3-3 | A—正文候选 | 在固定 Q2 和当前资源域下，最大新增 C 类装备数为 141 台；正式集合装填模型的下界、上界均为 141，MIP gap=0。 | `outputs/q3/results.json`；`outputs/q3/summary.md`；`outputs/q3/q3_optimization_audit.md`；`outputs/q3/validation.json` | 这是固定 Q2 接口下的条件最优，不推广到其他 Q2 方案或其他时间域。 | “问题三—模型求解与最大性证明” | 图表类别：候选→选择结果比较；正文保留 141 的精确数字，图只展示结构。
| Q3-4 | A—正文候选 | 独立成对冲突模型再次得到 141；加入 \\(\\sum y_p\\ge142\\) 后不可行，因此“142 台不可行”与“141 台可行”共同闭合最大性。 | `outputs/q3/q3_optimality_audit.json`；`outputs/q3/validation.json`；`scripts/verify_q3_optimality.py` | 两种约束编码和独立事件展开均通过；`result3.xlsx` 的 141 行与结果 JSON 一致。 | “问题三—独立重编码与阈值验证” | 图表类别：双模型一致性/阈值验证；建议使用小型证据表，不增加第三张重复图。
| Q3-5 | B—条件性正文候选 | 141 台新增计划占用 10,152 个资源格；与 Q2 合并后共有 285 个活动计划、25,968 个不同资源格，Q2—Q3、Q3 内部均无冲突。 | `outputs/q3/validation.json`；`outputs/q3/result3.xlsx`；`outputs/q3/results.json` | 只在固定 Q2、固定 C 类模板和 ([0,643)\times[0,100)) 下成立。 | “问题三—结果与合并验证” | 图表类别：合并后资源布局/时间分布；可使用候选起点与选中起点双面板。

## 6. 辅助实验：Q2—Q3 联合情景扫描

| ID | 状态 | 新结论 | 主要证据 | 验证与边界 | 正文位置 | 图表需求 |
|---|---|---|---|---|---|---|
| S-Q23-1 | C—验证/敏感性 | 在若干固定总撤销数 (R\in\{6,8,10,12,15,19\}) 的联合扫描中，Q3 最大新增数分别为 141、139、127、132、108、106；该实验显示 Q2 背景变化会改变 Q3 容量。 | `outputs/q2_q3_pareto/summary.md`；`outputs/q2_q3_pareto/pareto_results.json` | 扫描中的 Q2 均标为 `FEASIBLE_INCUMBENT`，未证明各自完整字典序最优；不得改写正式 Q2/Q3 结论。 | “模型检验—跨问题情景分析”或附录 | 图表类别：情景/Pareto 比较；只有在重新确认情景接口后才制作正文图。

## 7. 复现脚本索引

### 问题一

- 求解：`scripts/solve_q1.py`
- 验证：`scripts/validate_q1.py`
- 结果：`outputs/q1/results.json`、`outputs/q1/conflict_pairs.csv`、`outputs/q1/result1.xlsx`

### 问题二

- 主求解：`scripts/solve_q2_cp_sat.py`、`scripts/solve_q2_stage.py`
- 阈值证明：`scripts/prove_q2_thresholds.py`、`scripts/prove_q2_sat.py`
- 导入与验证：`scripts/import_q2_workbook.py`、`scripts/validate_q2.py`
- 结果：`outputs/q2/results.json`、`outputs/q2/result2.xlsx`、`outputs/q2/validation.json`

### 问题三

- 求解：`scripts/solve_q3.py`
- 独立最优性：`scripts/verify_q3_optimality.py`
- 验证：`scripts/validate_q3.py`
- 结果：`outputs/q3/results.json`、`outputs/q3/result3.xlsx`、`outputs/q3/validation.json`

## 8. 当前进入论文的建议顺序

1. 先写 DP-1—DP-3，形成独立的“数据预处理”一级标题。
2. 写 Q1-1—Q1-5，锁定冲突检测口径和 Q2 输入接口。
3. 写 Q2-1—Q2-4，随后把 Q2-5 放入模型检验，把 Q2-6 放入最优性边界。
4. 写 Q3-1—Q3-5，明确“固定 Q2 条件下的最大值”。
5. 最后决定是否把 S-Q23-1 纳入敏感性分析。
6. 图表先依据本台账确定表达对象，再重新绘制；现有图只作为数据和结构参考，不直接视为新论文终稿。

