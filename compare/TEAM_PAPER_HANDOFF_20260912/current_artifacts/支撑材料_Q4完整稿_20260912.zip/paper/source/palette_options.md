# 全文科研配色备选

为避免各图“各自好看、全文不统一”，三套方案使用相同的语义映射、图形编码、数据和版式，只替换低饱和颜色。蓝色表示主要证据或选中对象，青色表示调整，蓝灰表示保留或候选背景，橙/陶土色表示类别对照，锈红色仅表示撤销或警示。

| 方案 | 主要证据 | 调整 | 保留/候选背景 | 对照 | 撤销/警示 | 视觉气质 |
|---|---|---|---|---|---|---|
| A | `#3B6686` | `#4F8F8A` | `#6F8796` | `#C17B3A` | `#C47767` | 冷静、蓝—青—橙 |
| B | `#356C8C` | `#5C9690` | `#7893A3` | `#B98555` | `#9C5F6A` | 蓝—青关系更强，段式构成更柔和，已选定 |
| C | `#2F5D7E` | `#5B8A86` | `#7E91A0` | `#C29A5A` | `#A7635D` | 更沉稳，适合正文较密和灰度打印 |

三套方案已经按同一脚本生成 Q1、Q2、Q3 的完整 quantitative figure 集合：

这里的“完整”指当前保留在正文中的定量图；流程图不纳入配色选择，待用户自行重画后再单独接入。

- 综合预览：[palette_comparison.png](figures/palette_comparison.png)；同时提供 [palette_comparison.pdf](figures/palette_comparison.pdf)。
- 方案 A：[palette_A/fig2_q1_conflict_matrix.png](figures/palette_A/fig2_q1_conflict_matrix.png)、[palette_A/fig4_q2_composition.png](figures/palette_A/fig4_q2_composition.png)、[palette_A/fig5_q3_candidate_layout.png](figures/palette_A/fig5_q3_candidate_layout.png)。
- 方案 B：[palette_B/fig2_q1_conflict_matrix.png](figures/palette_B/fig2_q1_conflict_matrix.png)、[palette_B/fig4_q2_composition.png](figures/palette_B/fig4_q2_composition.png)、[palette_B/fig5_q3_candidate_layout.png](figures/palette_B/fig5_q3_candidate_layout.png)。
- 方案 C：[palette_C/fig2_q1_conflict_matrix.png](figures/palette_C/fig2_q1_conflict_matrix.png)、[palette_C/fig4_q2_composition.png](figures/palette_C/fig4_q2_composition.png)、[palette_C/fig5_q3_candidate_layout.png](figures/palette_C/fig5_q3_candidate_layout.png)。

当前 PDF 已统一采用方案 B；方案 A、C 仍保留作对照，不改变任何模型、数据、统计口径或结论。
