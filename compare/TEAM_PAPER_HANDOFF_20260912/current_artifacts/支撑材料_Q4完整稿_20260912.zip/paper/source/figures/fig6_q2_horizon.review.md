# Q2边界敏感性

- 证据：`outputs/q2/boundary_sensitivity.json`
- 表达对象：H=638、643、648下最小撤销数均为6
- 配色预览：方案 B。
- 交付：独立 PDF、SVG、PNG 与灰度预览。
- 限制：图形只表达已冻结证据，不升级模型结论。
