# 跨问题流程

- 证据：`work/evidence/Q123_NEW_CONCLUSION_EVIDENCE.md`
- 表达对象：DP-1--DP-3与Q1→Q2→Q3的单向证据接口
- 配色预览：方案 B。
- 交付：独立 PDF、SVG、PNG 与灰度预览。
- 限制：图形只表达已冻结证据，不升级模型结论。
