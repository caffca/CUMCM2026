# Q3候选布局

- 证据：`outputs/q3/plot_data/selected_start_positions.csv`
- 表达对象：固定Q2条件下的可行候选与141个选中起点
- 配色预览：方案 B。
- 交付：独立 PDF、SVG、PNG 与灰度预览。
- 限制：图形只表达已冻结证据，不升级模型结论。
