# 新论文图表计划（仅表达对象，不使用旧图作为终稿）

## 统一视觉规则

- 风格：证据优先的冷静科研风。
- 类别色：低饱和蓝—橙或蓝—青；同一语义对象在全篇保持同色。
- 连续变量：使用感知均匀色图，不使用彩虹色。
- 版式：优先二维、白底、少量辅助线；最终图导出 PDF/SVG，并生成 PNG 与灰度预览。
- 图表分工：表格承载精确数值，图形承载结构、比较、分布或敏感性。
- 当前 outputs/q1/figures/、outputs/q2/figures/、outputs/q3/figures/ 只作为数据和结构参考；重新绘制后才进入新稿。

## 图表清单

下表的“图号”沿用资产编号，便于追踪源文件；删除正文图 3、图 6 后，最终 PDF 的显示编号由 LaTeX 自动连续生成，不强行保留空号。

| 图号 | 图表类别 | 支持的结论 | 输入证据 | 计划表达 | 状态 |
|---|---|---|---|---|---|
| 图1 | 跨问题流程图 | DP-1—DP-3，以及 Q1→Q2→Q3 的单向接口 | work/evidence/Q123_NEW_CONCLUSION_EVIDENCE.md、各问结果 JSON | 原始计划 → 重复事件 → 时频资源格 → Q1 冲突边 → Q2 候选动作 → Q3 候选装填 | 用户后续重画：当前正文暂不采用，现有源稿仅保留作结构参考 |
| 图2 | 冲突结构/类别比较 | Q1-3、Q1-4 | outputs/q1/conflict_pairs.csv、outputs/q1/plot_data/ | 左侧展示冲突结构，右侧展示六类组合的冲突率；不重复列出 297 条清单 | 已完成：独立矢量图与灰度预览 |
| 图3 | 证明链/目标层级图 | Q2-2、Q2-3、Q2-6 | outputs/q2/q2_proof_matrix.csv、outputs/q2/revocation_bound.json | 原拟用图形表达目标层级，但三线表已完整承载上下界和证明状态 | 正文不采用：保留源资产作审计参考 |
| 图4 | 类别构成比较 | Q2-4 | outputs/q2/validation.json、outputs/q2/six_revocation_candidate.json | A/B/C 的保留、调整、撤销构成；精确动作清单放附录 | 已完成：独立矢量图与灰度预览 |
| 图5 | 候选空间/布局图 | Q3-2、Q3-3、Q3-5 | outputs/q3/plot_data/、outputs/q3/results.json | 展示 2,334 个可行候选与 141 个选中候选的起点结构；不把分布误写成优化目标 | 已完成：独立矢量图与灰度预览 |
| 图6 | 边界情景比较 | Q2-5 | outputs/q2/boundary_sensitivity.json | 原拟用图形比较 H=638、643、648；三线表已同时给出候选动作数、最小撤销数和验证状态 | 正文不采用：保留源资产作审计参考 |

## 暂不纳入

Q2—Q3 联合扫描 S-Q23-1 暂不制作正文图。扫描中的 Q2 方案均为可行 incumbent，尚未全部完成完整字典序证明；只有后续重新确认其用途和证据等级后，才考虑作为模型检验附图。

## 当前输出位置

- 正文采用的图形位于 `figures/`，由 LaTeX 的 `figure` 环境自动编号；图内不嵌入“图 n”字样。原图 3、图 6 的源资产仍保留，但正文以三线表承载相同证据。
- 图 1 的可编辑源稿为 `figures_src/fig1_pipeline.mmd`，当前不嵌入正文，待用户重新绘制后再替换。
- 图 2、图 4、图 5 由 `figures_src/build_figures.py` 从冻结的 Q1—Q3 证据重新生成，不读取旧 PNG 的像素或旧图中文字；原图 3、图 6 仅作为已生成的审计参考。
- `figures/palette_A/`、`figures/palette_B/`、`figures/palette_C/` 保存三套完整 quantitative figure 预览；`figures/palette_comparison.png` 用于横向选择。当前编译稿已统一使用用户选定的 B，A、C 仅作对照保留。
- 每幅图均保留 PDF、SVG、PNG 和灰度预览，并配有 `.visual.toml` 与 `.review.md` 记录表达对象和检查边界。
