#!/usr/bin/env python3
"""Conflict-generation proof search for the Q4 maximum active-plan count.

The master problem contains one at-most-one action choice per plan and
maximizes active plans.  After each master solution, every conflict edge
incident to a selected action is added as a valid cut.  The master is always
a relaxation of the full conflict model, so an OPTIMAL master value <=147 is
a global proof that no R<=2 schedule exists.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path

from ortools.sat.python import cp_model

from scripts.solve_q1 import read_plans
from scripts.solve_q4_cp_sat import Candidate, build_candidates, summarize


def candidate_key(candidate: Candidate) -> tuple:
    return (
        candidate.plan_id,
        candidate.action,
        candidate.df,
        candidate.dt,
        candidate.dg,
    )


def make_conflict_graph(
    plans: list[dict], candidates: list[Candidate]
) -> tuple[list[list[int]], list[list[int]], int, dict[tuple[int, int], list[int]]]:
    plan_index = {plan["id"]: index for index, plan in enumerate(plans)}
    by_plan: list[list[int]] = [[] for _ in plans]
    for index, candidate in enumerate(candidates):
        by_plan[plan_index[candidate.plan_id]].append(index)
    by_cell: defaultdict[tuple[int, int], list[int]] = defaultdict(list)
    for index, candidate in enumerate(candidates):
        for cell in candidate.cells:
            by_cell[cell].append(index)
    edges: set[tuple[int, int]] = set()
    for indexes in by_cell.values():
        if len(indexes) < 2:
            continue
        for left_position, left in enumerate(indexes):
            left_plan = plan_index[candidates[left].plan_id]
            for right in indexes[left_position + 1 :]:
                if left_plan == plan_index[candidates[right].plan_id]:
                    continue
                edges.add((left, right) if left < right else (right, left))
    neighbors: list[list[int]] = [[] for _ in candidates]
    for left, right in edges:
        neighbors[left].append(right)
        neighbors[right].append(left)
    return by_plan, neighbors, len(edges), by_cell


def make_full_values(
    all_candidates: list[Candidate],
    active_candidates: list[Candidate],
    selected: list[int | None],
    plans: list[dict],
) -> list[int]:
    values = [0] * len(all_candidates)
    lookup = {candidate_key(candidate): index for index, candidate in enumerate(all_candidates)}
    for candidate_index in selected:
        if candidate_index is None:
            continue
        candidate = active_candidates[candidate_index]
        values[lookup[candidate_key(candidate)]] = 1
    selected_plans = {candidate.plan_id for candidate_index in selected if candidate_index is not None for candidate in [active_candidates[candidate_index]]}
    for plan in plans:
        if plan["id"] not in selected_plans:
            values[lookup[(plan["id"], "revoke", 0, 0, 0)]] = 1
    return values


def configure_solver(time_limit: float, workers: int, seed: int) -> cp_model.CpSolver:
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_search_workers = workers
    solver.parameters.random_seed = seed
    solver.parameters.cp_model_presolve = True
    solver.parameters.linearization_level = 2
    solver.parameters.symmetry_level = 2
    solver.parameters.search_branching = cp_model.PORTFOLIO_SEARCH
    solver.parameters.log_search_progress = False
    return solver


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("data/raw/D题/附件/附件1.xlsx"))
    parser.add_argument("--horizon", type=int, default=643)
    parser.add_argument("--iterations", type=int, default=30)
    parser.add_argument("--time-limit", type=float, default=60.0)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--seed", type=int, default=20260912)
    parser.add_argument("--cut-mode", choices=["edge", "cell"], default="edge")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    plans = read_plans(args.input)
    all_candidates = build_candidates(plans, args.horizon)
    active_candidates = [candidate for candidate in all_candidates if candidate.action != "revoke"]
    by_plan, neighbors, edge_count, by_cell = make_conflict_graph(plans, active_candidates)

    model = cp_model.CpModel()
    variables = [model.new_bool_var(f"x_{index}") for index in active_candidates]
    for indexes in by_plan:
        model.add_at_most_one(variables[index] for index in indexes)
    model.maximize(sum(variables))

    cut_set: set[tuple[int, int]] = set()
    cell_cut_set: set[tuple[int, int]] = set()
    records = []
    last_selected: list[int | None] | None = None
    for iteration in range(args.iterations):
        solver = configure_solver(args.time_limit, args.workers, args.seed + iteration)
        status = solver.solve(model)
        status_name = solver.status_name(status)
        record = {
            "iteration": iteration,
            "status": status_name,
            "wall_time_seconds": solver.wall_time,
            "objective_value": None,
            "best_objective_bound": float(solver.best_objective_bound),
            "cuts_before": len(cell_cut_set) if args.cut_mode == "cell" else len(cut_set),
            "cuts_added": 0,
            "selected_active": None,
            "selected_conflicts": None,
        }
        if status_name not in {"OPTIMAL", "FEASIBLE"}:
            records.append(record)
            break
        selected = [None] * len(plans)
        selected_set: set[int] = set()
        for plan_index, indexes in enumerate(by_plan):
            for candidate_index in indexes:
                if solver.value(variables[candidate_index]):
                    selected[plan_index] = candidate_index
                    selected_set.add(candidate_index)
                    break
        active_count = len(selected_set)
        conflict_pairs = {
            (left, right) if left < right else (right, left)
            for left in selected_set
            for right in neighbors[left]
            if right in selected_set
        }
        if args.cut_mode == "cell":
            selected_cells = {
                cell
                for candidate_index in selected_set
                for cell in active_candidates[candidate_index].cells
            }
            new_cells = {
                cell
                for cell in selected_cells
                if cell not in cell_cut_set and len(by_cell[cell]) >= 2
            }
            for cell in new_cells:
                model.add(sum(variables[index] for index in by_cell[cell]) <= 1)
            cell_cut_set.update(new_cells)
            cuts_added = len(new_cells)
        else:
            # Add every conflict edge incident to a selected action.  This is
            # a stronger valid cut-generation step than adding only the
            # exposed selected-selected conflicts.
            new_cuts = set()
            for left in selected_set:
                for right in neighbors[left]:
                    edge = (left, right) if left < right else (right, left)
                    if edge not in cut_set:
                        new_cuts.add(edge)
            for left, right in new_cuts:
                model.add_bool_or([variables[left].Not(), variables[right].Not()])
            cut_set.update(new_cuts)
            cuts_added = len(new_cuts)
        record.update(
            {
                "objective_value": active_count,
                "selected_active": active_count,
                "selected_conflicts": len(conflict_pairs),
                "cuts_added": cuts_added,
            }
        )
        records.append(record)
        last_selected = selected
        if status_name == "OPTIMAL" and active_count <= 147:
            # The master with its accumulated valid cuts is a relaxation of
            # the complete conflict model.  Its optimum is therefore a valid
            # upper bound for the complete model.
            break
        if cuts_added == 0:
            break

    final_status = records[-1]["status"] if records else "NO_RUN"
    proof = "NOT_PROVED"
    if records and records[-1]["status"] == "OPTIMAL" and records[-1]["objective_value"] is not None and records[-1]["objective_value"] <= 147:
        proof = "PROVED_R_GE_3_BY_CONFLICT_GENERATION"
    summary = None
    if last_selected is not None:
        values = make_full_values(all_candidates, active_candidates, last_selected, plans)
        summary = summarize(plans, all_candidates, values)
    payload = {
        "question": "D-Q4",
        "mode": "conflict_generation_max_active",
        "method": "CP-SAT master with iteratively generated valid candidate-conflict cuts",
        "status": final_status,
        "proof": proof,
        "time_domain": [0, args.horizon],
        "frequency_domain": [0, 100],
        "plan_count": len(plans),
        "active_candidate_count": len(active_candidates),
        "full_conflict_edge_count": edge_count,
        "cut_mode": args.cut_mode,
        "cut_count": len(cell_cut_set) if args.cut_mode == "cell" else len(cut_set),
        "iterations": len(records),
        "records": records,
        "summary": summary,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": final_status, "proof": proof, "cuts": payload["cut_count"], "records": len(records), "output": str(args.output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
