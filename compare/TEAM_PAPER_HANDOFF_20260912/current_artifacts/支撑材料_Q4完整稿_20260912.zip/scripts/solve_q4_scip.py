#!/usr/bin/env python3
"""Independent SCIP feasibility check for the D-Q4 finite-action model."""
from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path

from pyscipopt import Model, quicksum

from scripts.solve_q1 import read_plans
from scripts.solve_q4_cp_sat import build_candidates, feature_vectors, summarize


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("data/raw/D题/附件/附件1.xlsx"))
    parser.add_argument("--horizon", type=int, default=643)
    parser.add_argument("--upper-revoke", type=int, default=2)
    parser.add_argument("--fix-revoke", type=int)
    parser.add_argument("--fix-revoke-a", type=int)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    plans = read_plans(args.input)
    candidates = build_candidates(plans, args.horizon)
    features = feature_vectors(candidates)
    model = Model("D-Q4-finite-actions")
    model.hideOutput()
    model.setParam("limits/time", args.time_limit)
    model.setParam("limits/gap", 0.0)

    variables = [model.addVar(vtype="B", name=f"x_{index}") for index in range(len(candidates))]
    by_plan: defaultdict[str, list[int]] = defaultdict(list)
    by_cell: defaultdict[tuple[int, int], list[int]] = defaultdict(list)
    for index, candidate in enumerate(candidates):
        by_plan[candidate.plan_id].append(index)
        for cell in candidate.cells:
            by_cell[cell].append(index)

    for indexes in by_plan.values():
        model.addCons(quicksum(variables[index] for index in indexes) == 1)
    resource_rows = 0
    for indexes in by_cell.values():
        if len(indexes) >= 2:
            model.addCons(quicksum(variables[index] for index in indexes) <= 1)
            resource_rows += 1

    revoke_sum = quicksum(features["revoke"][i] * variables[i] for i in range(len(variables)))
    if args.fix_revoke is not None:
        model.addCons(revoke_sum == args.fix_revoke)
    else:
        model.addCons(revoke_sum <= args.upper_revoke)
    if args.fix_revoke_a is not None:
        model.addCons(
            quicksum(features["revoke_A"][i] * variables[i] for i in range(len(variables)))
            == args.fix_revoke_a
        )

    model.optimize()
    status = model.getStatus()
    status_name = str(status).upper()
    best_solution = model.getBestSol()
    summary = None
    objective_values = None
    if best_solution is not None:
        values = [int(model.getSolVal(best_solution, variable) > 0.5) for variable in variables]
        summary = summarize(plans, candidates, values)
        objective_values = {
            name: int(sum(features[name][i] * values[i] for i in range(len(values))))
            for name in features
        }

    payload = {
        "question": "D-Q4",
        "mode": "independent_scip_feasibility",
        "method": "SCIP MIP + finite actions + resource-cell clique constraints",
        "status": status_name,
        "proof": "PROVED_INFEASIBLE" if status_name == "INFEASIBLE" else "NOT_INFEASIBLE",
        "time_domain": [0, args.horizon],
        "frequency_domain": [0, 100],
        "candidate_count": len(candidates),
        "resource_cell_constraint_count": resource_rows,
        "upper_bounds": {"revoke": args.upper_revoke} if args.fix_revoke is None else {},
        "fixed": {"revoke": args.fix_revoke} if args.fix_revoke is not None else {},
        "fixed_revoke_A": args.fix_revoke_a,
        "optimization": {
            "time_limit_seconds": args.time_limit,
            "wall_time_seconds": model.getSolvingTime(),
            "n_solutions": model.getNSols(),
            "n_nodes": model.getNNodes(),
            "n_constraints": model.getNConss(),
            "n_variables": model.getNVars(),
        },
        "objective_values": objective_values,
        "summary": summary,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": status_name, "solutions": model.getNSols(), "output": str(args.output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
