import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const repoRoot = "C:/Users/ysw/Desktop/CUMCM2026";
const templatePath = `${repoRoot}/data/raw/D题/附件/附件2/result2.xlsx`;
const resultsPath = `${repoRoot}/outputs/q2/results.json`;
const outputPath = `${repoRoot}/outputs/q2/result2.xlsx`;
const previewPath = `${repoRoot}/tmp/artifact-q2/result2_preview.png`;

const results = JSON.parse(await fs.readFile(resultsPath, "utf8"));
const input = await FileBlob.load(templatePath);
const workbook = await SpreadsheetFile.importXlsx(input);
const sheet = workbook.worksheets.getItem("Sheet1");
const expectedHeaders = ["用频装备编号", "调整后频段区间", "调整后时间区间", "是否撤销用频计划"];
const actualHeaders = sheet.getRange("A1:D1").values[0];
if (JSON.stringify(actualHeaders) !== JSON.stringify(expectedHeaders)) {
  throw new Error(`Unexpected result2 template headers: ${JSON.stringify(actualHeaders)}`);
}

const rows = results.summary.actions.map((row) => [
  row["装备编号"],
  row["动作"] === "freq" ? row["频段区间"] : null,
  row["动作"] === "time" ? row["时间区间"] : null,
  row["动作"] === "revoke" ? "是" : null,
]);
const lastRow = rows.length + 1;
sheet.getRange(`A2:D${lastRow}`).values = rows;
sheet.getRange(`A2:D${lastRow}`).format.font = { name: "宋体", size: 10 };
sheet.getRange(`A2:D${lastRow}`).format.horizontalAlignment = "center";
sheet.getRange(`A2:D${lastRow}`).format.verticalAlignment = "center";

workbook.recalculate();
const formulaAudit = await workbook.inspect({
  kind: "formula",
  sheetId: "Sheet1",
  range: `A1:D${lastRow}`,
  maxChars: 3000,
  options: { maxResults: 20 },
});
const preview = await workbook.render({
  sheetName: "Sheet1",
  range: "A1:D20",
  scale: 2,
  format: "png",
});
await fs.writeFile(previewPath, new Uint8Array(await preview.arrayBuffer()));
const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);

const exported = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
const exportedSheet = exported.worksheets.getItem("Sheet1");
const verification = {
  sheetNames: [exportedSheet.name],
  rowCount: exportedSheet.getUsedRange(true).rowCount,
  headers: exportedSheet.getRange("A1:D1").values[0],
  firstRows: exportedSheet.getRange("A2:D4").values,
  lastRows: exportedSheet.getRange(`A${lastRow - 2}:D${lastRow}`).values,
  expectedActionRows: rows.length,
  formulaAudit: formulaAudit.ndjson,
};
process.stdout.write(`${JSON.stringify(verification, null, 2)}\n`);
