#!/usr/bin/env python3
"""Independently audit the Q4 R<=2 SAT branch-cover proof.

The verifier does not trust the solver summaries to establish coverage.  It
rebuilds the active candidate conflict sets, checks the dominance reduction
count, and checks that the six nonnegative category partitions of two
revocations are present exactly once and each carries an UNSAT result.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path

from scripts.solve_q1 import read_plans
from scripts.solve_q4_cp_sat import build_candidates


EXPECTED_PARTITIONS = {
    (0, 0, 2),
    (0, 1, 1),
    (0, 2, 0),
    (1, 0, 1),
    (1, 1, 0),
    (2, 0, 0),
}


def independent_dominance_counts(plans: list[dict], horizon: int) -> dict:
    all_candidates = build_candidates(plans, horizon)
    active = [candidate for candidate in all_candidates if candidate.action != "revoke"]
    by_cell: defaultdict[tuple[int, int], list[int]] = defaultdict(list)
    by_plan: defaultdict[str, list[int]] = defaultdict(list)
    for index, candidate in enumerate(active):
        by_plan[candidate.plan_id].append(index)
        for cell in candidate.cells:
            by_cell[cell].append(index)

    neighbors = [set() for _ in active]
    for indexes in by_cell.values():
        for position, left in enumerate(indexes):
            for right in indexes[position + 1 :]:
                if active[left].plan_id != active[right].plan_id:
                    neighbors[left].add(right)
                    neighbors[right].add(left)

    removed: set[int] = set()
    for indexes in by_plan.values():
        for left in indexes:
            if left in removed:
                continue
            for right in indexes:
                if left == right:
                    continue
                if neighbors[right] <= neighbors[left] and (
                    neighbors[right] != neighbors[left] or right < left
                ):
                    removed.add(left)
                    break
    return {
        "input_active_candidate_count": len(active),
        "removed_active_candidate_count": len(removed),
        "kept_active_candidate_count": len(active) - len(removed),
        "plan_count": len(plans),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("data/raw/D题/附件/附件1.xlsx"))
    parser.add_argument("--horizon", type=int, default=643)
    parser.add_argument("--proof", action="append", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    plans = read_plans(args.input)
    dominance = independent_dominance_counts(plans, args.horizon)
    observed = []
    errors = []
    for path in args.proof:
        payload = json.loads(path.read_text(encoding="utf-8"))
        counts = payload.get("revoke_category_counts") or {}
        partition = tuple(int(counts.get(category, -1)) for category in "ABC")
        observed.append(partition)
        if payload.get("status") != "UNSAT" or payload.get("proof") != "PROVED_INFEASIBLE":
            errors.append(f"{path}: status/proof is not UNSAT/PROVED_INFEASIBLE")
        if payload.get("time_domain") != [0, args.horizon]:
            errors.append(f"{path}: time domain mismatch")
        if payload.get("target_active") != 148 or payload.get("exact_revokes") != 2:
            errors.append(f"{path}: threshold metadata mismatch")
        if payload.get("candidate_count") != dominance["kept_active_candidate_count"]:
            errors.append(f"{path}: reduced candidate count mismatch")
    if len(observed) != len(set(observed)):
        errors.append("duplicate category partition")
    if set(observed) != EXPECTED_PARTITIONS:
        errors.append(f"partition coverage mismatch: {sorted(set(observed))}")
    if dominance != {
        "input_active_candidate_count": 5953,
        "removed_active_candidate_count": 420,
        "kept_active_candidate_count": 5533,
        "plan_count": 150,
    }:
        errors.append(f"independent dominance count mismatch: {dominance}")

    payload = {
        "question": "D-Q4",
        "mode": "global_R_le_2_proof_coverage_validation",
        "status": "PASS" if not errors else "FAIL",
        "proof": "GLOBAL_BRANCH_COVERAGE_CONFIRMED" if not errors else "NOT_CONFIRMED",
        "time_domain": [0, args.horizon],
        "frequency_domain": [0, 100],
        "independent_dominance_reconstruction": dominance,
        "expected_partitions": [list(item) for item in sorted(EXPECTED_PARTITIONS)],
        "observed_partitions": [list(item) for item in observed],
        "proof_files": [str(path) for path in args.proof],
        "errors": errors,
        "logic": {
            "exact_two_revocations_equivalent_to_R_le_2": True,
            "partition_identity": "R_A+R_B+R_C=2, R_A,R_B,R_C>=0",
            "dominance_reduction_equivalence": True,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": payload["status"], "proof": payload["proof"], "output": str(args.output)}, ensure_ascii=False))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
