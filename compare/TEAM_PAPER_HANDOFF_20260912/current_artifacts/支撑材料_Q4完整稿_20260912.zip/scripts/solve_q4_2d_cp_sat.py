#!/usr/bin/env python3
"""Solve D-Q4 with optional rectangles and CP-SAT AddNoOverlap2D.

This is an independent formulation of the finite-action model.  A selected
action is represented by one optional rectangle for each repeated event; the
rectangle's time and frequency intervals are passed to AddNoOverlap2D.  It
therefore avoids expanding every rectangle into one Boolean variable per
resource cell while preserving the same half-open integer-grid semantics.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path

from ortools.sat.python import cp_model

from scripts.solve_q1 import read_plans
from scripts.solve_q4_cp_sat import (
    OBJECTIVE_ORDER,
    Candidate,
    build_candidates,
    feature_vectors,
    q2_hint,
    summarize,
)


def build_model(
    plans: list[dict],
    candidates: list[Candidate],
    threshold_revoke: int | None,
    fixed_revoke: int | None,
    maximize_active: bool,
) -> tuple[cp_model.CpModel, list[cp_model.IntVar], int]:
    model = cp_model.CpModel()
    variables = [model.new_bool_var(f"x_{index}") for index in range(len(candidates))]
    by_plan: defaultdict[str, list[int]] = defaultdict(list)
    uses_by_plan = {plan["id"]: int(plan["uses"]) for plan in plans}

    for index, candidate in enumerate(candidates):
        by_plan[candidate.plan_id].append(index)

    for indexes in by_plan.values():
        if maximize_active:
            model.add_at_most_one(variables[index] for index in indexes)
        else:
            model.add_exactly_one(variables[index] for index in indexes)

    if threshold_revoke is not None:
        revoke_variables = [
            variables[index]
            for index, candidate in enumerate(candidates)
            if candidate.action == "revoke"
        ]
        model.add(sum(revoke_variables) <= threshold_revoke)
    if fixed_revoke is not None:
        revoke_variables = [
            variables[index]
            for index, candidate in enumerate(candidates)
            if candidate.action == "revoke"
        ]
        model.add(sum(revoke_variables) == fixed_revoke)

    time_intervals = []
    frequency_intervals = []
    rectangle_count = 0
    for index, candidate in enumerate(candidates):
        if candidate.action == "revoke":
            continue
        assert candidate.frequency is not None
        assert candidate.time is not None
        assert candidate.gap is not None
        f0, f1 = candidate.frequency
        t0, t1 = candidate.time
        duration = t1 - t0
        step = duration + candidate.gap
        for event_index in range(uses_by_plan[candidate.plan_id]):
            event_t0 = t0 + event_index * step
            event_t1 = event_t0 + duration
            time_intervals.append(
                model.new_optional_interval_var(
                    event_t0,
                    duration,
                    event_t1,
                    variables[index],
                    f"t_{index}_{event_index}",
                )
            )
            frequency_intervals.append(
                model.new_optional_interval_var(
                    f0,
                    f1 - f0,
                    f1,
                    variables[index],
                    f"f_{index}_{event_index}",
                )
            )
            rectangle_count += 1

    model.add_no_overlap_2d(time_intervals, frequency_intervals)
    if maximize_active:
        model.maximize(sum(variables))
    return model, variables, rectangle_count


def configure_solver(args: argparse.Namespace) -> cp_model.CpSolver:
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = args.time_limit
    solver.parameters.num_search_workers = args.workers
    solver.parameters.random_seed = args.seed
    solver.parameters.cp_model_presolve = True
    solver.parameters.linearization_level = 2
    solver.parameters.symmetry_level = 2
    solver.parameters.search_branching = {
        "automatic": cp_model.AUTOMATIC_SEARCH,
        "fixed": cp_model.FIXED_SEARCH,
        "portfolio": cp_model.PORTFOLIO_SEARCH,
        "randomized": cp_model.RANDOMIZED_SEARCH,
        "quick_restart": cp_model.PORTFOLIO_WITH_QUICK_RESTART_SEARCH,
    }[args.search_branching]
    solver.parameters.randomize_search = args.randomize_search
    solver.parameters.random_branches_ratio = args.random_branches_ratio
    solver.parameters.log_search_progress = False
    return solver


def candidate_key(candidate: Candidate) -> tuple:
    return (
        candidate.plan_id,
        candidate.action,
        candidate.df,
        candidate.dt,
        candidate.dg,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("data/raw/D题/附件/附件1.xlsx"))
    parser.add_argument("--horizon", type=int, default=643)
    parser.add_argument("--mode", choices=["threshold", "max_active"], default="threshold")
    parser.add_argument("--upper-revoke", type=int)
    parser.add_argument("--fix-revoke", type=int)
    parser.add_argument("--q2-hint", type=Path)
    parser.add_argument("--prefer-active", action="store_true")
    parser.add_argument(
        "--search-branching",
        choices=["automatic", "fixed", "portfolio", "randomized", "quick_restart"],
        default="automatic",
    )
    parser.add_argument("--randomize-search", action="store_true")
    parser.add_argument("--random-branches-ratio", type=float, default=0.0)
    parser.add_argument("--time-limit", type=float, default=300.0)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--seed", type=int, default=20260912)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.mode == "threshold" and args.upper_revoke is None and args.fix_revoke is None:
        raise ValueError("threshold mode needs --upper-revoke or --fix-revoke")

    plans = read_plans(args.input)
    all_candidates = build_candidates(plans, args.horizon)
    maximize_active = args.mode == "max_active"
    candidates = (
        [candidate for candidate in all_candidates if candidate.action != "revoke"]
        if maximize_active
        else all_candidates
    )
    model, variables, rectangle_count = build_model(
        plans,
        candidates,
        args.upper_revoke if args.mode == "threshold" else None,
        args.fix_revoke if args.mode == "threshold" else None,
        maximize_active,
    )

    hint = q2_hint(all_candidates, args.q2_hint)
    if hint is not None:
        hint_by_key = {
            candidate_key(candidate): value
            for candidate, value in zip(all_candidates, hint)
        }
        for variable, candidate in zip(variables, candidates):
            model.add_hint(variable, hint_by_key.get(candidate_key(candidate), 0))
    if args.prefer_active:
        active_variables = [
            variables[index]
            for index, candidate in enumerate(candidates)
            if candidate.action != "revoke"
        ]
        if active_variables:
            model.add_decision_strategy(
                active_variables,
                cp_model.CHOOSE_FIRST,
                cp_model.SELECT_MAX_VALUE,
            )

    solver = configure_solver(args)
    status = solver.solve(model)
    status_name = solver.status_name(status)
    values = None
    if status_name in {"OPTIMAL", "FEASIBLE"}:
        values = [int(solver.value(variable)) for variable in variables]

    summary = None
    objective_values = None
    if values is not None:
        selected_by_key = {
            candidate_key(candidate): value
            for candidate, value in zip(candidates, values)
        }
        original_values = [
            selected_by_key.get(candidate_key(candidate), 0)
            for candidate in all_candidates
        ]
        summary = summarize(plans, all_candidates, original_values)
        features = feature_vectors(all_candidates)
        objective_values = {
            name: int(
                sum(features[name][i] * original_values[i] for i in range(len(original_values)))
            )
            for name in OBJECTIVE_ORDER
        }
        if maximize_active:
            objective_values["active"] = int(sum(values))

    payload = {
        "question": "D-Q4",
        "mode": "independent_2d_threshold" if args.mode == "threshold" else "independent_2d_max_active",
        "method": "OR-Tools CP-SAT + finite actions + optional rectangles + AddNoOverlap2D",
        "status": status_name,
        "proof": (
            "PROVED_OPTIMAL" if maximize_active and status_name == "OPTIMAL"
            else "PROVED_INFEASIBLE" if status_name == "INFEASIBLE"
            else "FEASIBLE_WITNESS" if values is not None
            else "NOT_PROVED"
        ),
        "time_domain": [0, args.horizon],
        "frequency_domain": [0, 100],
        "candidate_count": len(candidates),
        "all_candidate_count": len(all_candidates),
        "rectangle_count": rectangle_count,
        "upper_bounds": {"revoke": args.upper_revoke} if args.upper_revoke is not None else {},
        "fixed": {"revoke": args.fix_revoke} if args.fix_revoke is not None else {},
        "optimization": {
            "objective": "maximize_active" if maximize_active else None,
            "status": status_name,
            "time_limit_seconds": args.time_limit,
            "wall_time_seconds": solver.wall_time,
            "objective_value": (
                float(solver.objective_value)
                if maximize_active and status_name in {"OPTIMAL", "FEASIBLE"}
                else None
            ),
            "best_objective_bound": float(solver.best_objective_bound) if maximize_active else None,
            "num_conflicts": solver.num_conflicts,
            "num_branches": solver.num_branches,
            "optimality": "PROVED" if maximize_active and status_name == "OPTIMAL" else "NOT_PROVED",
        },
        "objective_values": objective_values,
        "summary": summary,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "status": status_name,
                "proof": payload["proof"],
                "objective_values": objective_values,
                "bound": payload["optimization"]["best_objective_bound"],
                "output": str(args.output),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
