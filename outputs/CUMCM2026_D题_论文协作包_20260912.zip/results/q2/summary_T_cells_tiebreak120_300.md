# Q2 求解摘要

- policy: `T`
- mode: `full`
- proven_optimal: `False`
- plans: `150`
- candidate states: `4582`
- state conflict edges used: `270626`
- lazy cuts added: `0`
- solver iterations: `1`

## 目标向量

| 层 | 值 | 状态 | 下界 | gap | 秒 | CP 冲突 | 分支 |
|---|---:|---|---:|---:|---:|---:|---:|
| C | 6 | FIXED | 6.0 | 0.0 | 0.000 | None | None |
| M | 120 | FIXED | 120.0 | 0.0 | 0.000 | None | None |
| P_A | 15 | FEASIBLE | 7.0 | 0.5333333333333333 | 300.512 | 0 | 4910 |

## 分类统计

| 指标 | A | B | C | 总计 |
|---|---:|---:|---:|---:|
| 保留 | 5 | 2 | 17 | 24 |
| 调整 | 14 | 33 | 73 | 120 |
| 撤销 | 1 | 5 | 0 | 6 |

## 复验

- canonical validation: plans=150, occurrences=1277, conflicts=0, ok=True
- fast selected-state conflict count: `0`
- raw displacement: sum|df|=619, sum|dt|=114, max|df|=10, max|dt|=5; `S_sum=10D_sum`.

本文件由 `scripts/solve_d_q2.py` 生成；若 `proven_optimal=false`，不得将结果称为严格词典序最优。
